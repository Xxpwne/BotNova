#!/usr/bin/env python3
import os
import sys
import time
from datetime import datetime

def check_dependencies():
    required_modules = [
        'telebot',
        'requests',
        'Crypto',
        'MajorLogin_res_pb2',
        'google.protobuf'
    ]
    
    print("🔍 Checking dependencies...")
    
    for module in required_modules:
        try:
            if module == 'Crypto':
                from Crypto.Cipher import AES
            elif module == 'MajorLogin_res_pb2':
                import MajorLogin_res_pb2
            elif module == 'google.protobuf':
                from google.protobuf.timestamp_pb2 import Timestamp
            else:
                __import__(module)
            print(f"✅ {module}")
        except ImportError:
            print(f"❌ {module} is missing!")
            return False
    
    return True

def print_banner():
    banner = """
     اتصرف ياعرص
"""
    print(banner)

def check_files():
    required_files = [
        "XTOKEN.py",
        "MajorLogin_res_pb2.py",
        "requirements.txt"
    ]
    
    print("📁 Checking files...")
    
    for file in required_files:
        if os.path.exists(file):
            print(f"✅ {file}")
        else:
            print(f"❌ {file} is missing!")
            return False
    
    return True

def main():
    print_banner()
    
    # Print current time
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"📅 Date: {current_time}")
    print("=" * 50)
    
    # Check files
    if not check_files():
        print("\n❌ Missing required files!")
        print("💡 Run: python install.py to setup")
        return
    
    # Check dependencies
    if not check_dependencies():
        print("\n❌ Missing dependencies!")
        print("💡 Run: python install.py to install")
        return
    
    print("\n" + "=" * 50)
    print("✅ All checks passed!")
    print("\n⚡ Starting bot...")
    print("👨‍💻 Developer: DRAGON")
    print("📌 Commands: /ban, /xtoken, /info")
    print("=" * 50)
    
    # Import and run the bot
    try:
        from XTOKEN import bot
        print("\n🤖 Bot is running...")
        print("📱 Connect to your Telegram bot")
        print("💬 Use /start to begin")
        
        # Add a small delay
        time.sleep(2)
        
        # Start polling
        bot.infinity_polling()
        
    except Exception as e:
        print(f"\n❌ Error starting bot: {e}")
        print("💡 Make sure you added your bot token in XTOKEN.py")
        print("💡 Replace 'هنا التوكن يابرو' with your actual bot token")

if __name__ == "__main__":
    main()