#!/usr/bin/env python3
import subprocess
import sys
import os

def install_requirements():
    print("🔧 Installing requirements...")
    requirements = [
        "pyTelegramBotAPI==4.19.1",
        "requests==2.31.0",
        "pycryptodome==3.20.0",
        "protobuf==4.25.3",
        "google-protobuf==4.25.3"
    ]
    
    for package in requirements:
        print(f"📦 Installing {package}...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", package])
            print(f"✅ {package} installed successfully")
        except subprocess.CalledProcessError:
            print(f"❌ Failed to install {package}")
            return False
    
    return True

def check_protobuf_files():
    print("\n🔍 Checking protobuf files...")
    
    required_files = ["MajorLogin_res_pb2.py", "XTOKEN.py"]
    
    for file in required_files:
        if os.path.exists(file):
            print(f"✅ {file} exists")
        else:
            print(f"❌ {file} is missing!")
            return False
    
    return True

def setup_bot_token():
    print("\n🤖 Bot Setup")
    print("=" * 40)
    
    if os.path.exists("XTOKEN.py"):
        with open("XTOKEN.py", "r", encoding="utf-8") as f:
            content = f.read()
        
        if "هنا التوكن يابرو" in content:
            token = input("📝 Enter your Telegram Bot Token: ").strip()
            if token:
                content = content.replace("هنا التوكن يابرو", token)
                with open("XTOKEN.py", "w", encoding="utf-8") as f:
                    f.write(content)
                print("✅ Bot token updated!")
            else:
                print("⚠️ Please add your bot token manually in XTOKEN.py")
        else:
            print("✅ Bot token already configured")
    else:
        print("❌ XTOKEN.py not found!")

def main():
    print("🚀 FreeFire XToken Ban Bot - Setup")
    print("=" * 50)
    
    # Install requirements
    if not install_requirements():
        print("❌ Failed to install requirements!")
        return
    
    # Check files
    if not check_protobuf_files():
        print("❌ Missing required files!")
        return
    
    # Setup bot token
    setup_bot_token()
    
    print("\n" + "=" * 50)
    print("✅ Setup completed successfully!")
    print("\n📌 To run the bot:")
    print("1. Make sure you have all files")
    print("2. Run: python XTOKEN.py")
    print("3. Or run: python run.py")
    print("\n⚡ Bot commands:")
    print("- /start - Start bot")
    print("- /ban [token] - Ban account")
    print("- /xtoken [token] - XToken login + ban")
    print("- /info - Bot info")
    print("\n👨‍💻 Developer: DRAGON")
    print("=" * 50)

if __name__ == "__main__":
    main()