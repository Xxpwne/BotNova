{
    "bot_settings": {
        "developer": "DRAGON",
        "version": "2.0",
        "features": [
            "XToken Login",
            "Auto Ban",
            "Account Info",
            "Multi-Platform Support"
        ]
    },
    "ban_durations": {
        "1_day": "86400",
        "3_days": "259200",
        "6_days": "518400",
        "permanent": "permanent"
    },
    "game_servers": {
        "login_server": "https://loginbp.ggblueshark.com/MajorLogin",
        "data_server": "https://clientbp.ggblueshark.com/GetLoginData",
        "inspect_server": "https://100067.connect.garena.com/oauth/token/inspect"
    },
    "aes_keys": {
        "key": "Yg&tc%DEuh6%Zc^8",
        "iv": "6oyZDr22E3ychjM%"
    }
}